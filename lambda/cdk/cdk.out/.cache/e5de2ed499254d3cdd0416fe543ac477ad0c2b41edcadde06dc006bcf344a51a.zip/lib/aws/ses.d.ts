/**
 * SES Client Configuration
 */
import { SESClient } from '@aws-sdk/client-ses';
export declare const sesClient: SESClient;
//# sourceMappingURL=ses.d.ts.map