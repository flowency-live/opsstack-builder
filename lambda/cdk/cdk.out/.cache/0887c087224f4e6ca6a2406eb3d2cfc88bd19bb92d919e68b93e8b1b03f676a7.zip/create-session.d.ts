/**
 * Lambda: Create Session
 * Creates a new session in DynamoDB
 */
import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
export declare const handler: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
//# sourceMappingURL=create-session.d.ts.map